const Structure = require('./structure');

const struct = new Structure();
struct.readStdIn(() => startProcessing(struct));

function startProcessing(structure) {
  // THIS IS WHERE WE DO THE COOL STUFF
  var iterations = 10;
  var largestResults = [];
  var largestScore = -1;
  for (var i = 0; i < iterations; i++) {
    var arr = getRandomArray(structure.images.length);
    var score = calculateScore(arr, structure);
    if (score > largestScore) {
      largestResults = arr;
      largestScore = score;
    }
  }
  consoleOutArray(largestResults);
}

function consoleOutArray(results) {
  console.log(results.length);
  for (var i = 0; i < results.length; i++) {
    console.log(results[i]);
  }
}

function getRandomArray(size) {
  var result = [];
  for (var i = 0; i < size; i++) {
    result.push(i);
  }
  var shuffledResults = shuffle(result);
  return shuffledResults;
}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}


function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
}

function calculateScore(results, structure) {
  var score = 0;
  for (var i = 0; i < results.length - 1; i++) {
    score += interestFactor(structure.images[results[i]], structure.images[results[i+1]]);
  }
  return score;
}

function interestFactor(img1, img2) {
  var commonTags=0;
  var in1only=0;
  var in2onlyMap={};
  img2.tags.forEach(i => {
    in2onlyMap[i]=1;
  });
  img1.tags.forEach((t1) => {
    if(img2.tags.includes(t1)) {
      commonTags++;
    } else {
      in1only++;
    }
    delete in2onlyMap[t1]
  });
  var in2only=Object.keys(in2onlyMap).length;
  // console.log("common:",commonTags);
  // console.log("1only:",in1only);
  // console.log("2only:",in2only);
  return Math.min(commonTags, in1only, in2only);
}
